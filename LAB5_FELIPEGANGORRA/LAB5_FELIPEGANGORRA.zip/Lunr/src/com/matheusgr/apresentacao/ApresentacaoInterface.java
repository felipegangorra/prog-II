package com.matheusgr.apresentacao;

public interface ApresentacaoInterface {
	public String apresentacao();
}
